package com.cssdeom;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TaintFilter implements Filter{
	private static final String FILTER_JAVASCRIPT_STRING1 = "(((\\%3C)|<)(\\s|\\+)*script((\\p{Print}+ | \\p{Space}*)*((\\%3E)|>)))(\\p{Print})+|(cookie)";
	private static final String FILTER_JAVASCRIPT_STRING2 = "((\\%3C)|<)((\\%2F)|\\/)*[a-z0-9]+((\\%3E)|>)";
	private static final String FILTER_JAVASCRIPT_STRING3 = "(\\p{Print})*(((\\%2F)|\\/)(\\s|\\+)*(script))+(\\p{Print})*|"
			+ "(\\p{Print})*((alert)(\\s|\\+)*((\\%28)|\\())+(\\p{Print})*|"
			+ "(\\p{Print})*(((\\%3C)|<)(\\s|\\+)*(img|IMG|iframe|IFRAME)(\\s|\\+)+)(\\p{Print})*";
	//Identifies ASCII control characters
	private static final String FILTER_JAVASCRIPT_STRING4 = "(\\p{Print})*((\\%0[0-9])|(\\%1[0-9])|(\\%0[A-F])|(\\%1[A-F]))(\\p{Print})*";
	private static final String FILTER_JAVASCRIPT_STRING5 = "(\\p{Print})*(A(\\s|\\+)+HREF(\\s|\\+)*((\\%3D)|(=)))(\\p{Print})*";
	private static final String FILTER_SQL_STRING1 = "(\\p{Space}|\\p{Print})*((((select)|(delete))(\\p{Print}|\\p{Space})+from)"
			+ "|(insert\\p{Space}+into)|(update(\\p{Print}|\\p{Space})+set)|(alter\\p{Space}+table)"
			+ "|(drop\\p{Space}+table)|(create\\p{Space}+table)|(create\\p{Space}+view)"
			+ "|(create\\p{Space}+index)|(truncate\\p{Space}+table))(\\p{Print})*";
	
	private static final String FILTER_SQL_STRING2 = "(\\p{Space}|\\p{Print})*(((((\\%27)|(\'))(\\s|\\+)*(select)|((\\%27)|(\'))(\\s|\\+)*(delete))(\\p{Print}|\\p{Space})+from)"
			+ "|((\\%27)|(\'))(\\s|\\+)*(insert(\\p{Print}|\\p{Space})+into)|((\\%27)|(\'))(\\s|\\+)*(update(\\p{Print}|\\p{Space})+set)|((\\%27)|(\'))(\\s|\\+)*(alter(\\p{Print}|\\p{Space})+table)"
			+ "|((\\%27)|(\'))(\\s|\\+)*(drop(\\p{Print}|\\p{Space})+table)|((\\%27)|(\'))(\\s|\\+)*(create(\\p{Print}|\\p{Space})+table)"
			+ "|((\\%27)|(\'))(\\s|\\+)*(create(\\p{Print}|\\p{Space})+view)|((\\%27)|(\'))(\\s|\\+)*(create(\\p{Print}|\\p{Space})+index)"
			+ "|((\\%27)|(\'))(\\s|\\+)*(create(\\p{Print}|\\p{Space})+sequence)"
			+ "|((\\%27)|(\'))(\\s|\\+)*(truncate(\\p{Print}|\\p{Space})+table))(\\p{Print})*";
	private static final String FILTER_SQL_STRING3 = "((\\p{Space}|\\p{Print})*((\\%27)|(\'))(\\s|\\+)*or(\\p{Print})*)|((\\p{Space}|\\p{Print})*((\\%27)|(\'))(\\s|\\+)*and(\\p{Print})*)";
	private static final String FILTER_SQL_STRING4 = "(\\p{Print})*((\\%27)|(\'))(\\s|\\+)*((\\%2D)|-)((\\%2D)|-)(\\p{Print})*";
	private static final String FILTER_XSS_EVENTS = "(.*(onmouseover).*(\"|%22).*(\"|%22))";
	private static final String FILTER_XSS_FILTER = "(.*[;\'<>'\"{}|<>'\";`~:?].*)";
	//private static final String REFERER_FILTER = "(.*(tools)(\\-stage|\\-dev|\\-lt)*(.cisco.com/emco/)((ys1jig)|(ys2jig)|(ys3jig)|(ys4jig)|(jigsaw))(/).*)";
	private static final String REFERER_FILTER = "(.*((tools)(\\-stage|\\-dev|\\-lt)*(.cisco.com/emco/)((ys1jig)|(ys2jig)|(ys3jig)|(ys4jig)|(jigsaw))(/)|((sso-).*(.cisco.com))).*)";
	private Pattern regxPatternXSS;
	private Pattern regxPatternSQL;
	private Pattern regxPatternReferer;
	

	@Override
	public void destroy() {
		System.out.println("Filter destroied");

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
			FilterChain filterChain) throws IOException, ServletException {
		String decodedParameterValue,replacedParameterValue;
		boolean isValid = true; 
		System.out.println("Into do Filter");
		//ArrayList<String> paramNames = (ArrayList<String>) servletRequest.getParameterNames();
		Enumeration<String> paramNamesEnum =  servletRequest.getParameterNames();
		Map<String, String[]> ParamsMap = servletRequest.getParameterMap();
		while(paramNamesEnum.hasMoreElements()){
			String paramNames = paramNamesEnum.nextElement();
			System.out.println("Parameter name fetched : "+paramNames +"parameter Value"+(CharSequence) ((Object[])ParamsMap.get(paramNames))[0]);
			String parameterValue = (String)(CharSequence) ((Object[])ParamsMap.get(paramNames))[0];
			try {
				decodedParameterValue = URLDecoder.decode(parameterValue, "UTF-8");
			} catch(UnsupportedEncodingException uEE) {
				System.out.println("UnsupportedEncodingException"+uEE);
				decodedParameterValue = parameterValue;
			}catch(Exception e){
				System.out.println("Other Exception -- Ignore it"+e);
				decodedParameterValue = parameterValue;
			}
			System.out.println("decoded param value"+decodedParameterValue);
			replacedParameterValue = decodedParameterValue.replaceAll("[\u0000-\u001f]", "");
			System.out.println("replacedParameterValue: "+replacedParameterValue);
			parameterValue = replacedParameterValue;
			//System.out.println((String)paramNames.toString()+" :::"+((Object[])ParamsMap.get(paramNames))[0]);
			//System.out.println("The Param result"+(regxPattern.matcher((CharSequence) ((Object[])ParamsMap.get(paramNames))[0])).matches());
			//Matcher matcher = regxPatternXSS.matcher(parameterValue);
			Matcher matcherSQL = regxPatternSQL.matcher(parameterValue);
			//Matcher matcher = regxPatternSQL.matcher(parameterValue);
			System.out.println("SQL matcher "+matcherSQL);
			if(matcherSQL.matches()){
				System.out.println("Invalid input paramNames ::"+parameterValue);
				//servletRequest.setAttribute("uploadError", "Invalid input "+(CharSequence) ((Object[])ParamsMap.get(paramNames))[0]);
				isValid = false;
				matcherSQL.replaceAll("");
				//RequestDispatcher rd = servletRequest.getRequestDispatcher("securityCheck");
				//rd.forward(servletRequest,servletResponse);
				break;
			}else{
				String initialParameterValue = parameterValue;
				parameterValue = parameterValue.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
				parameterValue = parameterValue.replaceAll("\\(", "&#40;").replaceAll("\\)", "&#41;");
				parameterValue = parameterValue.replaceAll("'", "&#39;");
				parameterValue = parameterValue.replaceAll("eval\\((.*)\\)", "");
				parameterValue = parameterValue.replaceAll("[\\\"\\\'][\\s]*javascript:(.*)[\\\"\\\']","\"\"");
				parameterValue = parameterValue.replaceAll("script","");
				parameterValue = parameterValue.replaceAll("/((\\%3D)|(=))[^\\n]*((\\%27)|(\')|(\\-\\-)|(\\%3B)|(;))/i","");
				parameterValue = parameterValue.replaceAll("/((\\%27)|(\'))union/ix","");
				parameterValue = parameterValue.replaceAll("/\\w*((\\%27)|(\\'))((\\%6F)|o|(\\%4F))((\\%72)|r|(\\%52))/ix","");
				parameterValue = parameterValue.replaceAll("insert|update|delete|having|drop|(\'|%27).(and|or).(\'|%27)|(\'|%27).%7C{0,2}|%7C{2}","");  
				parameterValue = parameterValue.replaceAll("/((\\%3C)|<)((\\%69)|i|(\\%49))((\\%6D)|m|(\\%4D))((\\%67)|g|(\\%47))[^\n]+((\\%3E)|>)/I","");
				
				if(!initialParameterValue.equalsIgnoreCase(parameterValue)) {
					System.out.println("initialParameterValue not equals to paramterValue");
					isValid = false;
					break;
				}
			}	
		}
		String referrer = ((HttpServletRequest) servletRequest).getHeader("referer");
		System.out.println("Pattern for Referer: "+regxPatternReferer+" and referer URL is :"+referrer);
		if(referrer!=null){
			Matcher matcherReferer = regxPatternReferer.matcher(referrer);
			if(matcherReferer.matches()){
				System.out.println("Invalid referer :"+referrer);
				isValid=false;
			}
		}		
		if(isValid){
			filterChain.doFilter(servletRequest, servletResponse);
		}else{
			/*HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
			HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
			
			httpServletResponse.sendRedirect("https://tools-dev.cisco.com/emco/ys2jig/securityCheck");*/
			RequestDispatcher rd = servletRequest.getRequestDispatcher("securityCheck");
			rd.forward(servletRequest,servletResponse);
		}
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("Filter initialized");
		StringBuilder patternStrXSS = new StringBuilder();
		StringBuilder patternStrSQL = new StringBuilder();
		StringBuilder patternReferer = new StringBuilder();
		/*patternStrXSS//.append(FILTER_JAVASCRIPT_STRING1).append("|")
					.append(FILTER_JAVASCRIPT_STRING3).append("|")
					.append(FILTER_JAVASCRIPT_STRING4).append("|")
					.append(FILTER_JAVASCRIPT_STRING5).append("|");
		regxPatternXSS = Pattern.compile(patternStrXSS.toString());*/
		patternStrSQL.append(FILTER_SQL_STRING1).append("|")
		.append(FILTER_SQL_STRING2).append("|")
		.append(FILTER_SQL_STRING4).append("|")
		.append(FILTER_SQL_STRING3).append("|")
		.append(FILTER_XSS_EVENTS).append("|")
		.append(FILTER_XSS_FILTER);
		regxPatternSQL = Pattern.compile(patternStrSQL.toString());
		
		patternReferer.append(REFERER_FILTER);
		regxPatternReferer = Pattern.compile(patternReferer.toString());
		
	}

}
